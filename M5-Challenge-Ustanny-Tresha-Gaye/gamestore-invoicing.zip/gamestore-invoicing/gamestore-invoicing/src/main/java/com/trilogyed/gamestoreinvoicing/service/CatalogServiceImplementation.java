package com.trilogyed.gamestoreinvoicing.service;

import com.trilogyed.gamestorecatalog.util.feign.GamestoreCatalogClient;
import com.trilogyed.gamestorecatalog.viewModel.GameViewModel;
import com.trilogyed.gamestoreinvoicing.feign.GamestoreInvoicingClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public abstract class CatalogServiceImplementation implements InvoicingService{

    @Autowired
    private GamestoreInvoicingClient gamestoreInvoicingClient;

    @Override
    public GameViewModel getGame(long id) {
        return InvoicingService.getGame(id);
    }

    @Override
    public GameViewModel createGame(GameViewModel gameViewModel) {
        return InvoicingService.createGame(gameViewModel);
    }
}
