package com.trilogyed.gamestoreinvoicing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamestoreInvoicingApplicationTests {

	@Test
	void contextLoads() {
	}

}
